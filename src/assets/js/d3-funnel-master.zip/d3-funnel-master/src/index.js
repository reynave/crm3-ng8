// Export default to provide support for non-ES6 solutions
module.exports = require('./d3-funnel/D3Funnel.js').default;
